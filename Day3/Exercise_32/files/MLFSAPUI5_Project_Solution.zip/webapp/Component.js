sap.ui.define([
	"sap/ui/core/UIComponent",
	"demo/MLFSAPUI5_Project/model/models"
], function(UIComponent, models) {
	"use strict";
	return UIComponent.extend("demo.MLFSAPUI5_Project.Component", {
		metadata: {
			manifest: "json"
		},

		init: function() {
			UIComponent.prototype.init.apply(this, arguments);
			this.getRouter().initialize();
			this.setModel(models.createParameterModel(), "parameter");
			this.setModel(models.createResultModel(), "result");
			this.setModel(new sap.ui.model.json.JSONModel({}), "dataSource");
		}
	});
});