// Created by D064906
// For Workshop use only

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"d064906/test_model/model/models",
	'jquery.sap.global',
	'sap/m/MessageToast',
	'sap/m/MessageBox'
], function(Controller, models, jQuery, MessageToast, MessageBox) {
	"use strict";

	var image = null;
	
	return Controller.extend("d064906.test_model.controller.main", {
		onInit: function() {
			sap.ui.getCore().attachValidationError(function (evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("Error");
				}
			});
			sap.ui.getCore().attachValidationSuccess(function (evt) {
				var control = evt.getParameter("element");
				if (control && control.setValueState) {
					control.setValueState("None");
				}
			});
		},
		
		handleContinue : function (evt) {
			this.generateRequest();
		},
		
		handleTypeMismatch: function(oEvent) {
			var fileType = oEvent.getSource().getFileType();
			jQuery.each(fileType, function(key, value) {
				fileType[key] = "*." +  value;
			});
			var supportedFileTypes = fileType.join(", ");
			MessageToast.show("The file type *." + oEvent.getParameter("fileType") +
									" is not supported. Choose one of the following types: " +
									supportedFileTypes);
		},
		
		uploadImage: function(oEvent) {
			if(this.getView().byId("imageUpload").oFileUpload.files && this.getView().byId("imageUpload").oFileUpload.files[0]) {
				var fileReader = new FileReader();
				fileReader.onload = function (res) {
	                image = res.target.result;
	                $('.imagePreview')
	                    .attr('src', res.target.result)
	                    .width(100)
	                    .height(100);
	            };
	            fileReader.readAsDataURL(this.getView().byId("imageUpload").oFileUpload.files[0]);
			}
			
		},
		
		generateRequest: function(oEvent) {
			if(!this.getView().byId("imageUpload").oFileUpload.files[0]) {
				MessageToast.show("Choose a file first");
				return;
			}
			$('.result').text("error");
			$('.resultTitle').hide();
			$('.errorTitle').hide();
			$('.errorTxt').hide();
			$('.result').hide();
			$('.loader').fadeIn();
			var data = new FormData();
			data.append("file", this.getView().byId("imageUpload").oFileUpload.files[0])
			$.ajax({
				"async": true,
				"url": "/do_inference",
				"method": "POST",
				"headers": {
					"Cache-Control": "no-cache",
					"Postman-Token": "da88cd85-7123-8371-28e4-011f82cf6826"
				},
				"processData": false,
				"contentType": false,
				"mimeType": "multipart/form-data",
				"data": data
			}).done(function (response) {
				$('.loader').hide();
				setTimeout(function() {
					$('.result').text(response.slice(-1));
					$('.resultTitle').fadeIn().css("display","block");
					$('.result').fadeIn().css("display","block");
				}, 400);
			}).fail(function (jqXHR, textStatus) {
				$('.loader').hide();
				setTimeout(function() {
					$('.errorTitle').fadeIn().css("display","block");
					$('.errorTxt').fadeIn().css("display","block");
				}, 400);
			});
		}
	});
});