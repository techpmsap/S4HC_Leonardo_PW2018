package com.sap.cloud.sfsf;

import java.io.IOException;
import java.io.PrintWriter;

import javax.naming.Context;
//import javax.ws.rs.InternalServerErrorException;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sap.cloud.account.Account;
import com.sap.cloud.account.TenantContext;
import com.sap.core.connectivity.api.configuration.ConnectivityConfiguration;
import com.sap.core.connectivity.api.configuration.DestinationConfiguration;
import com.sap.security.um.user.PersistenceException;
import com.sap.security.um.user.UnsupportedUserAttributeException;
import com.sap.security.um.user.User;
import com.sap.security.um.user.UserProvider;

/**
 * Servlet implementation class ConnectivityServlet
 */
@WebServlet("/Connect")
public class ConnectivityServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final String DESTINATION_NAME = "search_engine_destination";
	private static final Logger LOGGER = LoggerFactory.getLogger(ConnectivityServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ConnectivityServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String  CurrentUser;
		// Get ResposeWriter
		PrintWriter out = response.getWriter();
		out.println("<HTML><TITLE>Java Basics for Extensions</TITLE><BODY>");
		out.println("<H1>SAP Cloud Platform - Basics of Building Extension Apps</H1><BR/><BR/>");
		try {
			// Get Tenant Context and Read Properties
			Context ctx = new InitialContext();
			TenantContext tenantContext = (TenantContext) ctx.lookup("java:comp/env/TenantContext");

			
			out.println("<H3>SAP Cloud Platform - Tenant Account Demo</H3><BR>");
			
			
			//Wrap in Try/Catch block to catch runtime exception which is thrown on local server
			try {
				Account account = tenantContext.getTenant().getAccount();
				out.println("Application was accesses from SAP Cloud Platform  Account Name: " + account.getName() + "<BR/>");
				out.println("The application was accessed on behalf of a tenant with an ID: " + account.getId()
						+ account.getName() + "<BR/>");
			} catch (IllegalArgumentException e) {
				LOGGER.debug("Can not access Tenant object on local server.", e);
				out.println("Tenant details not accessible on local server.<BR/>");
			}

			
			ConnectivityConfiguration configuration = (ConnectivityConfiguration) ctx
					.lookup("java:comp/env/connectivityConfiguration");

			//Get Destination Details
			DestinationConfiguration destConfiguration = configuration.getConfiguration(DESTINATION_NAME);

			// Get the destination URL
			String baseUrl = destConfiguration.getProperty("URL");
			out.println("<BR/><BR/><H3>SAP Cloud Platform - Multitenant Connectivity Application Demo</H3><BR/>");
			out.println("Application is using  Destination: " + DESTINATION_NAME + "<BR/>");
			out.println("Base URL used in destination: " + baseUrl + "<BR/>");

			
			
			//Get User Details, Check Role
			UserProvider userProvider = (UserProvider) ctx.lookup("java:comp/env/user/Provider");
			User user = null;
			CurrentUser = null;
			if (request.getUserPrincipal() != null) {
				user = userProvider.getUser(request.getUserPrincipal().getName());
				CurrentUser = request.getUserPrincipal().toString();
				}
			out.println("<BR/><BR/><H3>SAP Cloud Platform - Access User Details Demo</H3><BR/>");
			out.println("Current logon user id is: " + CurrentUser + "<BR/>");
			out.println("First Name is Current logon user is: " + user.getAttribute("firstname") + "<BR/>");
			out.println("Last Name of Current logon user is: " + user.getAttribute("lastname") + "<BR/>");
			out.println("Email address of  Current logon user is: " + user.getAttribute("email") + "<BR/>");
			out.println("Assigned groups: " + user.getAttribute("groups") + "<BR/>");

			if (!request.isUserInRole("Admin")) {
				response.sendError(403, "Logged in user does not have role Administrator");
			} else {
				out.println("Hello administrator<BR/>");
			}
			
		} catch (PersistenceException | UnsupportedUserAttributeException | NamingException e) {
			LOGGER.error("Error Encountered: " + e.getLocalizedMessage(), e);
			out.println("<H1>Error Encountered: " + e.getLocalizedMessage() + "</H1>");
		}
		
		out.println("</BODY></HTML>");

	}

}
